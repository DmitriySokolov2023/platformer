module Main (main) where

import Game (runGame)

main :: IO ()
main = runGame