module World
  ( Screen (..), InputState (..), App (..), initialApp, startPlaying, goTitle, stepWorld
  ) where

import Game.Constants (moveSpeed, playerWidth, windowWidth)

data Screen
  = Title
  | Playing
  deriving (Eq, Show)

data InputState = InputState
  { inputLeft :: Bool,
    inputRight :: Bool
  }
  deriving (Eq, Show)

data App = App
  { appScreen :: Screen,
   appInput :: InputState,
   playerX :: Float
  }
  deriving (Eq, Show)

initialApp :: App
initialApp =
  App
    { appScreen = Title
    , appInput = InputState {inputLeft = False, inputRight = False}
    , playerX = 0
    }

startPlaying :: App -> App
startPlaying app =
  case appScreen app of
    Title ->
      app
        { appScreen = Playing
        , appInput = InputState {inputLeft = False, inputRight = False}
        , playerX = 0
        }
    Playing -> app

goTitle :: App -> App
goTitle app =
  case appScreen app of
    Playing ->
      app
        { appScreen = Title
        , appInput = InputState {inputLeft = False, inputRight = False}
        }
    Title -> app

stepWorld :: Float -> App -> App
stepWorld dt app =
  case appScreen app of
    Title -> app
    Playing -> movePlayer dt app

movePlayer :: Float -> App -> App
movePlayer dt app =
  app {playerX = clamp minX maxX (playerX app + dx)}
  where
    dir = boolToFloat (inputRight (appInput app)) - boolToFloat (inputLeft (appInput app))
    dx = dir * moveSpeed * dt
    halfW = fromIntegral windowWidth / 2
    halfPlayerW = playerWidth / 2
    minX = -halfW + halfPlayerW
    maxX = halfW - halfPlayerW

boolToFloat :: Bool -> Float
boolToFloat b =
  if b then 1 else 0

clamp :: Float -> Float -> Float -> Float
clamp lo hi x
  | x < lo = lo
  | x > hi = hi
  | otherwise = x