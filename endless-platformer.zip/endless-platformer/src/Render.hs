module Render (drawAppIO) where

import Graphics.Gloss

import Game.Constants
import World (App (..), Screen (..))

drawAppIO :: App -> IO Picture
drawAppIO = pure . drawApp

drawApp :: App -> Picture
drawApp app =
  case appScreen app of
    Title   -> drawTitle
    Playing -> drawPlaying app

drawTitle :: Picture
drawTitle =
  pictures
    [ translate titleX titleY
        $ scale titleScale titleScale
        $ color titleColor
        $ Text titleText
    , translate hintX hintY
        $ scale hintScale hintScale
        $ color hintColor
        $ Text hintText
    ]

drawPlaying :: App -> Picture
drawPlaying app =
  pictures
    [ drawGround
    , drawPlayer app
    , drawPlayingUi
    ]

drawPlayingUi :: Picture
drawPlayingUi =
  pictures
    [ translate playingX playingY
        $ scale playingScale playingScale
        $ color playingColor
        $ Text playingText
    , translate playingHintX playingHintY
        $ scale playingHintScale playingHintScale
        $ color playingHintColor
        $ Text playingHintText
    ]

drawGround :: Picture
drawGround =
  translate 0 groundY
    $ color groundColor
    $ rectangleSolid (fromIntegral windowWidth) groundHeight

drawPlayer :: App -> Picture
drawPlayer app =
  translate (playerX app) playerY
    $ color playerColor
    $ rectangleSolid playerWidth playerHeight